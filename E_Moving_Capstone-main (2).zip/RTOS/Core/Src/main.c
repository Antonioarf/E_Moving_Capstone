/* USER CODE BEGIN Header */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
typedef struct {
	 int button_id, button_status;
} command;

void printer(char msg){
	ITM_SendChar(msg);
	ITM_SendChar('\n');

}

char* osStatusToString(osStatus_t status) {
    switch (status) {
        case osOK:
            return "OK: Operation completed successfully\r\n";
        case osError:
            return "osError: Unspecified error\r\n";
        case osErrorTimeout:
            return "Timeout: osErrorTimeout:  Operation timed out\r\n";
        case osErrorResource:
            return "Resource: osErrorResource: Resource not available\r\n";
        case osErrorParameter:
            return "Parameter: osErrorParameter: Parameter error\r\n";
        case osErrorNoMemory:
            return "NoMemory: osErrorNoMemory: System is out of memory\r\n";
        default:
            return "Unknown osStatus_t\r\n";
    }
}
//osStatus_t status=  osMessageQueuePut(Input_queueHandle, &com, 0, 0);
//char* str = osStatusToString(status);
//HAL_UART_Transmit(&huart1, str, sizeof(str), 500);

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart1;

/* Definitions for BT_reader */
osThreadId_t BT_readerHandle;
const osThreadAttr_t BT_reader_attributes = {
  .name = "BT_reader",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for MT_controller */
osThreadId_t MT_controllerHandle;
const osThreadAttr_t MT_controller_attributes = {
  .name = "MT_controller",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for Sensor_Read */
osThreadId_t Sensor_ReadHandle;
const osThreadAttr_t Sensor_Read_attributes = {
  .name = "Sensor_Read",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for Input_queue */
osMessageQueueId_t Input_queueHandle;
const osMessageQueueAttr_t Input_queue_attributes = {
  .name = "Input_queue"
};
/* Definitions for BT_send */
osMessageQueueId_t BT_sendHandle;
const osMessageQueueAttr_t BT_send_attributes = {
  .name = "BT_send"
};
/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_I2C1_Init(void);
void BT_reader_funct(void *argument);
void MT_controller_funct(void *argument);
void Sensor_reader_funct(void *argument);

/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of Input_queue */
  Input_queueHandle = osMessageQueueNew (16, sizeof(command), &Input_queue_attributes);

  /* creation of BT_send */
  BT_sendHandle = osMessageQueueNew (16, sizeof(char*), &BT_send_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of BT_reader */
  BT_readerHandle = osThreadNew(BT_reader_funct, NULL, &BT_reader_attributes);

  /* creation of MT_controller */
  MT_controllerHandle = osThreadNew(MT_controller_funct, NULL, &MT_controller_attributes);

  /* creation of Sensor_Read */
  Sensor_ReadHandle = osThreadNew(Sensor_reader_funct, NULL, &Sensor_Read_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();


  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x2000090E;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */
  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */
  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */
  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin : BREAK_Pin */
  GPIO_InitStruct.Pin = BREAK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(BREAK_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

int FON_UART_Receive(char *received, uint16_t timeout) {
    HAL_StatusTypeDef status;
    unsigned char receivedChar;
    int index = 0;

    while (1) {
        status = HAL_UART_Receive(&huart1, &receivedChar, 1, timeout);

        if (status == HAL_OK) {
            if (receivedChar == '\n') {
            	received[index] = '\0';

                return 1;
            } else {
                received[index] = receivedChar;
                index++;
            }
        } else {
            received[0] = '\0';
            return 0;
        }
    }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	command com;

	if (GPIO_Pin == BREAK_Pin) {
		com.button_id 		= 1;
		if (HAL_GPIO_ReadPin(BREAK_GPIO_Port, GPIO_Pin) == GPIO_PIN_SET) {
			// Your code for rising edge -> apertou
			com.button_status  	= 0;
			osStatus_t status=  osMessageQueuePut(Input_queueHandle, &com, 0, 0);
				if (status != osOK){
				char* str = osStatusToString(status);
				osMessageQueuePut(BT_sendHandle, &str, 0, 0);
			}
		} else {
			// Your code for falling edge -> soltou
			com.button_status  	= 1;
			osStatus_t status 	=  osMessageQueuePut(Input_queueHandle, &com, 0, 0);
			if (status != osOK){
				char* str = osStatusToString(status);
				osMessageQueuePut(BT_sendHandle, &str, 0, 0);
			}
		}
	}
}

/* USER CODE END 4 */

/* USER CODE BEGIN Header_BT_reader_funct */
/* USER CODE END Header_BT_reader_funct */
void BT_reader_funct(void *argument)
{
  /* USER CODE BEGIN 5 */
	unsigned char str[14] ="\r\nIniciando \r\n";
	HAL_UART_Transmit(&huart1, str, sizeof(str), 500);

	char* res;
    char receivedData[32];
	command com;


	while (1) {
	        if (FON_UART_Receive(receivedData,500)){
	        	if (strlen(receivedData)==3){
	        		com.button_id 		= receivedData[0] - '0';
					com.button_status  	= 10*(receivedData[1] - '0') + (receivedData[2] - '0');
					osMessageQueuePut(Input_queueHandle, &com, 0, 2000);
	        	}
	        }


	        while (1){
	        	if (osMessageQueueGet(BT_sendHandle, &res, NULL, 250) == osOK) {
	        	    HAL_UART_Transmit(&huart1, res, strlen(res), 1000);
	        	}
	        	if (osMessageQueueGetCount(BT_sendHandle)==0){
	        		break;
	        	}

	        }

	        //osDelay(1000);
	        osThreadYield();
	}



  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_MT_controller_funct */
/**
* @brief Function implementing the MT_controller thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_MT_controller_funct */
void MT_controller_funct(void *argument)
{
  /* USER CODE BEGIN MT_controller_funct */
  /* Infinite loop */

	int auth = 0;
	command com;
	//int speed=0; // max = 255

	while(1){
		if (osMessageQueueGet(Input_queueHandle, &com, NULL, 2000)== osOK){
			if(com.button_id==9){
				auth = com.button_status;
				if (auth){
					char* str = "ABRIU\n";
				    osMessageQueuePut(BT_sendHandle, &str, 0, 2000);
				}
				else{
					char* str = "FECHOU\n";
				    osMessageQueuePut(BT_sendHandle, &str, 0, 2000);
					}
				}
			else if(com.button_id==1){
				auth = com.button_status;
				if (auth){
					char* str = "SOLTOU\n";
				    osMessageQueuePut(BT_sendHandle, &str, 0, 2000);
				}
				else{
					char* str = "FREIOU\n";
				    osMessageQueuePut(BT_sendHandle, &str, 0, 2000);
					}
				}

		}
		if(auth){}
		//osDelay(1000);
        osThreadYield();

	}
  /* USER CODE END MT_controller_funct */
}

/* USER CODE BEGIN Header_Sensor_reader_funct */
/**
* @brief Function implementing the Sensor_Read thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Sensor_reader_funct */
void Gyro_Sensor(void *argument)
{
  /* USER CODE BEGIN Sensor_reader_funct */
	#define MPU6050_ADDR 0xD0

	//Register location from datasheets
	#define SMPLRT_DIV_REG 0x19
	#define GYRO_CONFIG_REG 0x1B
	#define ACCEL_CONFIG_REG 0x1C
	#define ACCEL_XOUT_H_REG 0x3B
	#define TEMP_OUT_H_REG 0x41
	#define GYRO_XOUT_H_REG 0x43
	#define PWR_MGMT_1_REG 0x6B
	#define WHO_AM_I_REG 0x75
	int16_t Accel_X_RAW = 0;
	int16_t Accel_Y_RAW = 0;
	int16_t Accel_Z_RAW = 0;

	int16_t Gyro_X_RAW = 0;
	int16_t Gyro_Y_RAW = 0;
	int16_t Gyro_Z_RAW = 0;

	float Ax, Ay, Az, Gx, Gy, Gz;
	char* buf[4];

	//Initiation Function, write a data memory
	void MPU6050_Init(void)
	{
		I2C_HandleTypeDef hi2c1;
		uint8_t check;
		uint8_t Data;

		// check device ID WHO_AM_I

		HAL_I2C_Mem_Read (&hi2c1, MPU6050_ADDR,WHO_AM_I_REG,1, &check, 1, 1000);

		if (check == 104)  // 0x68 will be returned by the sensor if everything goes well
		{
			//When the sensor is powere, wake the sensor
			Data = 0;
			HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, PWR_MGMT_1_REG, 1,&Data, 1, 1000);

			// Set DATA RATE of 1KHz by writing SMPLRT_DIV register
			Data = 0x07;
			HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, SMPLRT_DIV_REG, 1, &Data, 1, 1000);

			// Set accelerometer configuration in ACCEL_CONFIG Register
			// AFS_SEL = 0
			Data = 0x00;
			HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, ACCEL_CONFIG_REG, 1, &Data, 1, 1000);

			// Set Gyroscopic configuration in GYRO_CONFIG Register
			// FS_SEL=0
			Data = 0x00;
			HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, GYRO_CONFIG_REG, 1, &Data, 1, 1000);
		}
	}

	//Read raw value and convert into acceleration
	void MPU6050_Read_Accel (void)
	{
		uint8_t Rec_Data[6];

		// Read 6 BYTES of data starting from ACCEL_XOUT_H register

		HAL_I2C_Mem_Read (&hi2c1, MPU6050_ADDR, ACCEL_XOUT_H_REG, 1, Rec_Data, 6, 1000);
		// Combine high 8 big and low 8 bit
		Accel_X_RAW = (int16_t)(Rec_Data[0] << 8 | Rec_Data [1]);
		Accel_Y_RAW = (int16_t)(Rec_Data[2] << 8 | Rec_Data [3]);
		Accel_Z_RAW = (int16_t)(Rec_Data[4] << 8 | Rec_Data [5]);


		// Acceleration = Raw / 16384 when AFS_SEL = 0
		Ax = Accel_X_RAW/16384.0;
		Ay = Accel_Y_RAW/16384.0;
		Az = Accel_Z_RAW/16384.0;
	}

	//Read raw data and convert into dps
	void MPU6050_Read_Gyro(void)
	{
			uint8_t Rec_Data[6];

			// Read 6 BYTES of data starting from GYRO_XOUT_H register

			HAL_I2C_Mem_Read (&hi2c1, MPU6050_ADDR, GYRO_XOUT_H_REG, 1, Rec_Data, 6, 1000);

			//Each each register are 8 bit size.
			//Raw = first high 8 bit + second low 8 bits
			Gyro_X_RAW = (int16_t)(Rec_Data[0] << 8 | Rec_Data [1]);
			Gyro_Y_RAW = (int16_t)(Rec_Data[2] << 8 | Rec_Data [3]);
			Gyro_Z_RAW = (int16_t)(Rec_Data[4] << 8 | Rec_Data [5]);



			// Convert Raw data into dps data. When FS_SEL = 0, dps = Raw / 131.
			Gx = Gyro_X_RAW/131.0;
			Gy = Gyro_Y_RAW/131.0;
			Gz = Gyro_Z_RAW/131.0;

	}

	MPU6050_Init();
	HAL_Delay (1000);  // wait for 1 sec
  /* Infinite loop */
	while(1)
	{
	  MPU6050_Read_Accel(); //Read the Acceraltion of X,Y, and Z direction, output Ax, Ay, Az
	  MPU6050_Read_Gyro();  //Read the Gyro Angle of X,Y, and Z direction, output Gx, Gy, Gz

	  HAL_Delay (250);  // wait for a while
	}
  /* USER CODE END Sensor_reader_funct */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */
  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */
  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
